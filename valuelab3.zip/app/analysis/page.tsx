"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel } from "@/components/ui/form"
import { Textarea } from "@/components/ui/textarea"
import { zodResolver } from "@hookform/resolvers/zod"
import { AlertCircle, ArrowRight, CheckCircle2, Loader2, ThumbsUp } from "lucide-react"
import { useState } from "react"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Progress } from "@/components/ui/progress"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Image from "next/image"

const formSchema = z.object({
  location: z.string({
    required_error: "Please select a location.",
  }),
  propertyType: z.string({
    required_error: "Please select a property type.",
  }),
  budget: z.string({
    required_error: "Please select a budget range.",
  }),
  investmentIdea: z
    .string()
    .min(20, {
      message: "Investment idea must be at least 20 characters.",
    })
    .max(1000, {
      message: "Investment idea must not exceed 1000 characters.",
    }),
})

type AnalysisResult = {
  viabilityScore: number
  successRate: number
  recommendations: string[]
  strengths: string[]
  weaknesses: string[]
  marketTrends: {
    label: string
    value: number
    change: "up" | "down" | "neutral"
  }[]
  locationData: {
    name: string
    image: string
    description: string
    growthRate: number
    avgPrice: string
    rentalYield: string
  }
}

// Indian cities for the location selector
const indianCities = [
  { value: "mumbai", label: "Mumbai" },
  { value: "delhi", label: "Delhi" },
  { value: "bangalore", label: "Bangalore" },
  { value: "hyderabad", label: "Hyderabad" },
  { value: "chennai", label: "Chennai" },
  { value: "kolkata", label: "Kolkata" },
  { value: "pune", label: "Pune" },
  { value: "ahmedabad", label: "Ahmedabad" },
  { value: "jaipur", label: "Jaipur" },
  { value: "lucknow", label: "Lucknow" },
  { value: "kochi", label: "Kochi" },
  { value: "chandigarh", label: "Chandigarh" },
  { value: "coimbatore", label: "Coimbatore" },
  { value: "goa", label: "Goa" },
  { value: "indore", label: "Indore" },
  { value: "nagpur", label: "Nagpur" },
  { value: "surat", label: "Surat" },
  { value: "bhubaneswar", label: "Bhubaneswar" },
  { value: "dehradun", label: "Dehradun" },
  { value: "vizag", label: "Visakhapatnam" },
]

// Property types
const propertyTypes = [
  { value: "apartment", label: "Apartment" },
  { value: "villa", label: "Villa" },
  { value: "plot", label: "Plot" },
  { value: "commercial", label: "Commercial Space" },
  { value: "office", label: "Office Space" },
  { value: "retail", label: "Retail Space" },
  { value: "warehouse", label: "Warehouse" },
]

// Budget ranges
const budgetRanges = [
  { value: "under-30l", label: "Under ₹30 Lakhs" },
  { value: "30l-50l", label: "₹30 Lakhs - ₹50 Lakhs" },
  { value: "50l-1cr", label: "₹50 Lakhs - ₹1 Crore" },
  { value: "1cr-2cr", label: "₹1 Crore - ₹2 Crore" },
  { value: "2cr-5cr", label: "₹2 Crore - ₹5 Crore" },
  { value: "above-5cr", label: "Above ₹5 Crore" },
]

// Location data for mock results
const locationData = {
  mumbai: {
    name: "Mumbai",
    image: "/images/mumbai-location.jpg",
    description: "India's financial capital with premium real estate and high demand.",
    growthRate: 8.5,
    avgPrice: "₹18,000 - ₹65,000 per sq.ft.",
    rentalYield: "2.5% - 3.5%",
  },
  delhi: {
    name: "Delhi",
    image: "/images/delhi-location.jpg",
    description: "The capital city with diverse real estate options and stable growth.",
    growthRate: 7.2,
    avgPrice: "₹12,000 - ₹45,000 per sq.ft.",
    rentalYield: "2.8% - 3.8%",
  },
  bangalore: {
    name: "Bangalore",
    image: "/images/bangalore-location.jpg",
    description: "India's tech hub with strong demand for both residential and commercial properties.",
    growthRate: 10.5,
    avgPrice: "₹5,500 - ₹25,000 per sq.ft.",
    rentalYield: "3.5% - 4.5%",
  },
  pune: {
    name: "Pune",
    image: "/images/pune-location.jpg",
    description: "Educational hub with growing IT sector and affordable housing options.",
    growthRate: 9.8,
    avgPrice: "₹5,000 - ₹15,000 per sq.ft.",
    rentalYield: "3.2% - 4.2%",
  },
  hyderabad: {
    name: "Hyderabad",
    image: "/images/hyderabad-location.jpg",
    description: "Emerging tech center with infrastructure development and affordable prices.",
    growthRate: 12.3,
    avgPrice: "₹4,500 - ₹12,000 per sq.ft.",
    rentalYield: "3.8% - 4.8%",
  },
  chennai: {
    name: "Chennai",
    image: "/images/chennai-location.jpg",
    description: "Industrial hub with stable real estate market and good rental potential.",
    growthRate: 7.8,
    avgPrice: "₹5,000 - ₹18,000 per sq.ft.",
    rentalYield: "3.0% - 4.0%",
  },
  // Default for other cities
  default: {
    name: "Selected City",
    image: "/images/india-map.jpg",
    description: "Growing urban center with investment potential in real estate.",
    growthRate: 8.0,
    avgPrice: "₹4,000 - ₹15,000 per sq.ft.",
    rentalYield: "3.0% - 4.0%",
  },
}

export default function AnalysisPage() {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [result, setResult] = useState<AnalysisResult | null>(null)
  const [progress, setProgress] = useState(0)
  const [activeTab, setActiveTab] = useState("overview")

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      investmentIdea: "",
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsAnalyzing(true)
    setProgress(0)
    setResult(null)
    setActiveTab("overview")

    // Simulate progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 5
      })
    }, 200)

    // Simulate API call with timeout
    setTimeout(() => {
      clearInterval(interval)
      setProgress(100)

      // Get location data based on selected city
      const cityData = locationData[values.location as keyof typeof locationData] || locationData.default

      // Generate scores based on location and property type
      const baseScore = Math.floor(Math.random() * 21) + 60 // 60-80
      const locationBonus =
        values.location === "bangalore" || values.location === "pune" || values.location === "hyderabad" ? 10 : 5
      const propertyBonus = values.propertyType === "apartment" || values.propertyType === "commercial" ? 8 : 5

      const viabilityScore = Math.min(98, baseScore + locationBonus)
      const successRate = Math.min(95, baseScore + propertyBonus)

      // Mock result with dynamic data based on form inputs
      const mockResult: AnalysisResult = {
        viabilityScore,
        successRate,
        recommendations: [
          `Consider investing in ${cityData.name}'s ${values.propertyType === "commercial" ? "commercial corridors" : "residential areas"} for better returns`,
          `Research local infrastructure development plans in ${cityData.name}`,
          `Evaluate potential for rental income in addition to capital appreciation`,
          `Check for upcoming government policies that might affect property values in ${cityData.name}`,
        ],
        strengths: [
          `${cityData.name} has a strong growth potential of ${cityData.growthRate}% annually`,
          `Good location with excellent connectivity and amenities`,
          `Positive demographic trends with increasing demand for ${values.propertyType} properties`,
        ],
        weaknesses: [
          "Potential regulatory challenges in the coming years",
          `Competition from nearby developments in ${cityData.name}`,
          "Seasonal demand fluctuations may affect short-term returns",
        ],
        marketTrends: [
          {
            label: "Property Prices",
            value: 8.5,
            change: "up",
          },
          {
            label: "Rental Yield",
            value: 3.8,
            change: "neutral",
          },
          {
            label: "Demand",
            value: 9.2,
            change: "up",
          },
          {
            label: "Supply",
            value: 7.5,
            change: "up",
          },
        ],
        locationData: cityData,
      }

      setResult(mockResult)
      setIsAnalyzing(false)
    }, 4000)
  }

  function getScoreColor(score: number) {
    if (score >= 80) return "text-green-500"
    if (score >= 70) return "text-emerald-500"
    if (score >= 60) return "text-yellow-500"
    return "text-red-500"
  }

  function getScoreProgressColor(score: number) {
    if (score >= 80) return "bg-green-500"
    if (score >= 70) return "bg-emerald-500"
    if (score >= 60) return "bg-yellow-500"
    return "bg-red-500"
  }

  function getTrendIcon(change: "up" | "down" | "neutral") {
    if (change === "up") return <TrendingUpIcon className="h-4 w-4 text-green-500" />
    if (change === "down") return <TrendingDownIcon className="h-4 w-4 text-red-500" />
    return <TrendingFlatIcon className="h-4 w-4 text-yellow-500" />
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="mb-8 text-center text-4xl font-bold text-emerald-500">Investment Analysis</h1>
      <div className="mx-auto max-w-4xl">
        <Card className="border-zinc-800 bg-zinc-950 p-6">
          <CardContent className="p-0">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid gap-6 md:grid-cols-3">
                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Location</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-zinc-900">
                              <SelectValue placeholder="Select a city" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="max-h-80">
                            <SelectGroup>
                              <SelectLabel>Major Cities</SelectLabel>
                              {indianCities.map((city) => (
                                <SelectItem key={city.value} value={city.value}>
                                  {city.label}
                                </SelectItem>
                              ))}
                            </SelectGroup>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="propertyType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Property Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-zinc-900">
                              <SelectValue placeholder="Select property type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectGroup>
                              <SelectLabel>Property Types</SelectLabel>
                              {propertyTypes.map((type) => (
                                <SelectItem key={type.value} value={type.value}>
                                  {type.label}
                                </SelectItem>
                              ))}
                            </SelectGroup>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="budget"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Budget Range</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-zinc-900">
                              <SelectValue placeholder="Select budget range" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectGroup>
                              <SelectLabel>Budget Ranges</SelectLabel>
                              {budgetRanges.map((range) => (
                                <SelectItem key={range.value} value={range.value}>
                                  {range.label}
                                </SelectItem>
                              ))}
                            </SelectGroup>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="investmentIdea"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-lg">Describe your real estate investment idea</FormLabel>
                      <FormDescription>
                        Include details about your investment goals, timeline, and any specific requirements.
                      </FormDescription>
                      <FormControl>
                        <Textarea
                          placeholder="I'm planning to invest in a property for long-term capital appreciation. I'm interested in areas with good connectivity and amenities..."
                          className="min-h-[150px] bg-zinc-900 text-white"
                          {...field}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <Button
                  type="submit"
                  className="w-full bg-emerald-600 text-white hover:bg-emerald-700"
                  disabled={isAnalyzing}
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      Analyze Investment <ArrowRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </form>
            </Form>

            {isAnalyzing && (
              <div className="mt-8 space-y-4">
                <p className="text-center text-gray-400">Analyzing your investment idea...</p>
                <Progress value={progress} className="h-2 bg-zinc-800" indicatorClassName="bg-emerald-500" />
                <div className="grid grid-cols-3 gap-4 text-center text-sm text-gray-400">
                  <div>Collecting data</div>
                  <div>Processing factors</div>
                  <div>Generating insights</div>
                </div>
              </div>
            )}

            {result && (
              <div className="mt-8 space-y-8">
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="location">Location Analysis</TabsTrigger>
                    <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
                  </TabsList>

                  <TabsContent value="overview" className="space-y-6 pt-4">
                    <div className="grid gap-6 md:grid-cols-2">
                      <div className="space-y-2 rounded-lg border border-zinc-800 bg-zinc-900 p-6">
                        <h3 className="text-lg font-medium">Viability Score</h3>
                        <div className="flex items-end justify-between">
                          <div className={`text-4xl font-bold ${getScoreColor(result.viabilityScore)}`}>
                            {result.viabilityScore}%
                          </div>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div className="flex cursor-help items-center text-sm text-gray-400">
                                  <InfoIcon className="mr-1 h-4 w-4" />
                                  What's this?
                                </div>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="max-w-xs">
                                  The viability score indicates the overall potential of your investment based on
                                  multiple factors including location, market trends, and economic indicators.
                                </p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                        <Progress
                          value={result.viabilityScore}
                          className="h-2 bg-zinc-800"
                          indicatorClassName={getScoreProgressColor(result.viabilityScore)}
                        />
                      </div>

                      <div className="space-y-2 rounded-lg border border-zinc-800 bg-zinc-900 p-6">
                        <h3 className="text-lg font-medium">Success Rate</h3>
                        <div className="flex items-end justify-between">
                          <div className={`text-4xl font-bold ${getScoreColor(result.successRate)}`}>
                            {result.successRate}%
                          </div>
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <div className="flex cursor-help items-center text-sm text-gray-400">
                                  <InfoIcon className="mr-1 h-4 w-4" />
                                  What's this?
                                </div>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p className="max-w-xs">
                                  The success rate represents the probability of achieving your stated investment goals
                                  based on historical data and market projections.
                                </p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                        <Progress
                          value={result.successRate}
                          className="h-2 bg-zinc-800"
                          indicatorClassName={getScoreProgressColor(result.successRate)}
                        />
                      </div>
                    </div>

                    <div className="rounded-lg border border-zinc-800 bg-zinc-900 p-6">
                      <h3 className="mb-4 text-lg font-medium">Market Trends</h3>
                      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                        {result.marketTrends.map((trend) => (
                          <div key={trend.label} className="rounded-lg border border-zinc-800 bg-zinc-950 p-4">
                            <div className="flex items-center justify-between">
                              <h4 className="text-sm font-medium text-gray-400">{trend.label}</h4>
                              {getTrendIcon(trend.change)}
                            </div>
                            <p className="mt-2 text-2xl font-bold">{trend.value}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Alert className="border-emerald-800 bg-emerald-950">
                      <ThumbsUp className="h-4 w-4 text-emerald-500" />
                      <AlertTitle className="text-emerald-500">Investment Strengths</AlertTitle>
                      <AlertDescription>
                        <ul className="mt-2 list-inside list-disc space-y-1">
                          {result.strengths.map((strength, index) => (
                            <li key={index} className="text-gray-300">
                              {strength}
                            </li>
                          ))}
                        </ul>
                      </AlertDescription>
                    </Alert>

                    <Alert className="border-amber-800 bg-amber-950">
                      <AlertCircle className="h-4 w-4 text-amber-500" />
                      <AlertTitle className="text-amber-500">Areas of Concern</AlertTitle>
                      <AlertDescription>
                        <ul className="mt-2 list-inside list-disc space-y-1">
                          {result.weaknesses.map((weakness, index) => (
                            <li key={index} className="text-gray-300">
                              {weakness}
                            </li>
                          ))}
                        </ul>
                      </AlertDescription>
                    </Alert>
                  </TabsContent>

                  <TabsContent value="location" className="space-y-6 pt-4">
                    <div className="overflow-hidden rounded-lg border border-zinc-800 bg-zinc-900">
                      <div className="relative h-64 w-full">
                        <Image
                          src={result.locationData.image || "/placeholder.svg"}
                          alt={result.locationData.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="p-6">
                        <h3 className="mb-2 text-2xl font-bold text-emerald-500">{result.locationData.name}</h3>
                        <p className="mb-4 text-gray-300">{result.locationData.description}</p>

                        <div className="grid gap-4 md:grid-cols-3">
                          <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-4">
                            <h4 className="text-sm font-medium text-gray-400">Annual Growth Rate</h4>
                            <p className="mt-1 text-xl font-bold text-emerald-500">{result.locationData.growthRate}%</p>
                          </div>
                          <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-4">
                            <h4 className="text-sm font-medium text-gray-400">Average Price</h4>
                            <p className="mt-1 text-xl font-bold">{result.locationData.avgPrice}</p>
                          </div>
                          <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-4">
                            <h4 className="text-sm font-medium text-gray-400">Rental Yield</h4>
                            <p className="mt-1 text-xl font-bold">{result.locationData.rentalYield}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-lg border border-zinc-800 bg-zinc-900 p-6">
                      <h3 className="mb-4 text-lg font-medium">Location Advantages</h3>
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="flex items-start rounded-lg border border-zinc-800 bg-zinc-950 p-4">
                          <div className="mr-4 rounded-full bg-emerald-500/10 p-2 text-emerald-500">
                            <BuildingIcon className="h-5 w-5" />
                          </div>
                          <div>
                            <h4 className="font-medium">Infrastructure</h4>
                            <p className="text-sm text-gray-400">
                              Well-developed infrastructure with good connectivity
                            </p>
                          </div>
                        </div>
                        <div className="flex items-start rounded-lg border border-zinc-800 bg-zinc-950 p-4">
                          <div className="mr-4 rounded-full bg-emerald-500/10 p-2 text-emerald-500">
                            <TrendingUpIcon className="h-5 w-5" />
                          </div>
                          <div>
                            <h4 className="font-medium">Growth Potential</h4>
                            <p className="text-sm text-gray-400">Strong economic growth driving real estate demand</p>
                          </div>
                        </div>
                        <div className="flex items-start rounded-lg border border-zinc-800 bg-zinc-950 p-4">
                          <div className="mr-4 rounded-full bg-emerald-500/10 p-2 text-emerald-500">
                            <UsersIcon className="h-5 w-5" />
                          </div>
                          <div>
                            <h4 className="font-medium">Demographics</h4>
                            <p className="text-sm text-gray-400">Growing population with increasing purchasing power</p>
                          </div>
                        </div>
                        <div className="flex items-start rounded-lg border border-zinc-800 bg-zinc-950 p-4">
                          <div className="mr-4 rounded-full bg-emerald-500/10 p-2 text-emerald-500">
                            <HomeIcon className="h-5 w-5" />
                          </div>
                          <div>
                            <h4 className="font-medium">Housing Demand</h4>
                            <p className="text-sm text-gray-400">Consistent demand for quality housing options</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="recommendations" className="space-y-6 pt-4">
                    <div className="rounded-lg border border-zinc-800 bg-zinc-900 p-6">
                      <h3 className="mb-4 text-lg font-medium text-emerald-500">Recommendations to Improve</h3>
                      <ul className="space-y-3">
                        {result.recommendations.map((recommendation, index) => (
                          <li key={index} className="flex items-start rounded-md bg-zinc-950 p-3">
                            <CheckCircle2 className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-emerald-500" />
                            <span>{recommendation}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="rounded-lg border border-zinc-800 bg-zinc-900 p-6">
                      <h3 className="mb-4 text-lg font-medium text-emerald-500">Investment Strategy</h3>
                      <div className="space-y-4">
                        <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-4">
                          <h4 className="mb-2 font-medium">Short-term (1-2 years)</h4>
                          <p className="text-sm text-gray-400">
                            Focus on establishing the property and ensuring proper documentation. Consider minor
                            improvements to enhance property value.
                          </p>
                        </div>
                        <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-4">
                          <h4 className="mb-2 font-medium">Medium-term (3-5 years)</h4>
                          <p className="text-sm text-gray-400">
                            Maximize rental income if applicable. Stay informed about local development projects that
                            could impact property value.
                          </p>
                        </div>
                        <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-4">
                          <h4 className="mb-2 font-medium">Long-term (5+ years)</h4>
                          <p className="text-sm text-gray-400">
                            Consider strategic renovations to maintain competitive edge. Evaluate market conditions for
                            optimal exit strategy if desired.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-lg border border-zinc-800 bg-zinc-900 p-6">
                      <h3 className="mb-4 text-lg font-medium text-emerald-500">Additional Resources</h3>
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-4">
                          <h4 className="mb-2 font-medium">Market Reports</h4>
                          <p className="text-sm text-gray-400">
                            Access detailed market reports for {result.locationData.name} to gain deeper insights.
                          </p>
                          <Button variant="link" className="mt-2 h-auto p-0 text-emerald-500">
                            View Reports
                          </Button>
                        </div>
                        <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-4">
                          <h4 className="mb-2 font-medium">Expert Consultation</h4>
                          <p className="text-sm text-gray-400">
                            Schedule a call with our real estate experts for personalized advice.
                          </p>
                          <Button variant="link" className="mt-2 h-auto p-0 text-emerald-500">
                            Book Consultation
                          </Button>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function InfoIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <path d="M12 16v-4" />
      <path d="M12 8h.01" />
    </svg>
  )
}

function TrendingUpIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
      <polyline points="17 6 23 6 23 12" />
    </svg>
  )
}

function TrendingDownIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="23 18 13.5 8.5 8.5 13.5 1 6" />
      <polyline points="17 18 23 18 23 12" />
    </svg>
  )
}

function TrendingFlatIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="22 12 18 12 15 12 8 12 6 12 2 12" />
    </svg>
  )
}

function BuildingIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect x="4" y="2" width="16" height="20" rx="2" ry="2" />
      <path d="M9 22v-4h6v4" />
      <path d="M8 6h.01" />
      <path d="M16 6h.01" />
      <path d="M12 6h.01" />
      <path d="M12 10h.01" />
      <path d="M12 14h.01" />
      <path d="M16 10h.01" />
      <path d="M16 14h.01" />
      <path d="M8 10h.01" />
      <path d="M8 14h.01" />
    </svg>
  )
}

function UsersIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  )
}

function HomeIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
      <polyline points="9 22 9 12 15 12 15 22" />
    </svg>
  )
}

