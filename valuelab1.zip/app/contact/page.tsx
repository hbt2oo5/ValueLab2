import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { AtSign, Mail, MapPin, Phone } from "lucide-react"

export default function ContactPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="mb-8 text-center text-4xl font-bold text-emerald-500">Contact Us</h1>
      <div className="mx-auto max-w-5xl">
        <div className="grid gap-8 md:grid-cols-2">
          <div>
            <Card className="border-zinc-800 bg-zinc-950">
              <CardHeader>
                <CardTitle className="text-2xl text-emerald-500">Get in Touch</CardTitle>
                <CardDescription>Have questions about ValueLab? We're here to help.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-start">
                  <Mail className="mr-3 h-5 w-5 text-emerald-500" />
                  <div>
                    <h3 className="font-medium">Email</h3>
                    <p className="text-sm text-gray-400">
                      <a href="mailto:harshalthorat635@gmail.com" className="hover:text-emerald-400">
                        harshalthorat635@gmail.com
                      </a>
                    </p>
                    <p className="text-sm text-gray-400">
                      <a href="mailto:vedantpawar5099@gmail.com" className="hover:text-emerald-400">
                        vedantpawar5099@gmail.com
                      </a>
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <Phone className="mr-3 h-5 w-5 text-emerald-500" />
                  <div>
                    <h3 className="font-medium">Phone</h3>
                    <p className="text-sm text-gray-400">+91 98765 43210</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <MapPin className="mr-3 h-5 w-5 text-emerald-500" />
                  <div>
                    <h3 className="font-medium">Location</h3>
                    <p className="text-sm text-gray-400">Mumbai, Maharashtra, India</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <AtSign className="mr-3 h-5 w-5 text-emerald-500" />
                  <div>
                    <h3 className="font-medium">Social Media</h3>
                    <div className="mt-2 flex space-x-4">
                      <a href="#" className="text-gray-400 hover:text-emerald-500">
                        Twitter
                      </a>
                      <a href="#" className="text-gray-400 hover:text-emerald-500">
                        LinkedIn
                      </a>
                      <a href="#" className="text-gray-400 hover:text-emerald-500">
                        Instagram
                      </a>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card className="border-zinc-800 bg-zinc-950">
              <CardHeader>
                <CardTitle className="text-2xl text-emerald-500">Send a Message</CardTitle>
                <CardDescription>
                  Fill out the form below and we'll get back to you as soon as possible.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form>
                  <form className="space-y-4">
                    <FormField
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Your name" className="bg-zinc-900" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="Your email" className="bg-zinc-900" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Message</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Your message" className="min-h-[120px] bg-zinc-900" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700">
                      Send Message
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

