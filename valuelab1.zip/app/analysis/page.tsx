"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel } from "@/components/ui/form"
import { Textarea } from "@/components/ui/textarea"
import { zodResolver } from "@hookform/resolvers/zod"
import { AlertCircle, ArrowRight, CheckCircle2, Loader2, ThumbsUp } from "lucide-react"
import { useState } from "react"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Progress } from "@/components/ui/progress"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

const formSchema = z.object({
  investmentIdea: z
    .string()
    .min(20, {
      message: "Investment idea must be at least 20 characters.",
    })
    .max(1000, {
      message: "Investment idea must not exceed 1000 characters.",
    }),
})

type AnalysisResult = {
  viabilityScore: number
  successRate: number
  recommendations: string[]
  strengths: string[]
  weaknesses: string[]
}

export default function AnalysisPage() {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [result, setResult] = useState<AnalysisResult | null>(null)
  const [progress, setProgress] = useState(0)

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      investmentIdea: "",
    },
  })

  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsAnalyzing(true)
    setProgress(0)
    setResult(null)

    // Simulate progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 5
      })
    }, 200)

    // Simulate API call with timeout
    setTimeout(() => {
      clearInterval(interval)
      setProgress(100)

      // Mock result - in a real app, this would come from your API
      const mockResult: AnalysisResult = {
        viabilityScore: Math.floor(Math.random() * 41) + 60, // 60-100
        successRate: Math.floor(Math.random() * 31) + 60, // 60-90
        recommendations: [
          "Consider diversifying across multiple properties in the same area",
          "Research local infrastructure development plans",
          "Evaluate potential for rental income in addition to capital appreciation",
          "Check for upcoming government policies that might affect property values",
        ],
        strengths: [
          "Good location with growth potential",
          "Reasonable price point for the market",
          "Positive demographic trends in the area",
        ],
        weaknesses: [
          "Potential regulatory challenges",
          "Competition from nearby developments",
          "Seasonal demand fluctuations",
        ],
      }

      setResult(mockResult)
      setIsAnalyzing(false)
    }, 4000)
  }

  function getScoreColor(score: number) {
    if (score >= 80) return "text-green-500"
    if (score >= 70) return "text-emerald-500"
    if (score >= 60) return "text-yellow-500"
    return "text-red-500"
  }

  function getScoreProgressColor(score: number) {
    if (score >= 80) return "bg-green-500"
    if (score >= 70) return "bg-emerald-500"
    if (score >= 60) return "bg-yellow-500"
    return "bg-red-500"
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="mb-8 text-center text-4xl font-bold text-emerald-500">Investment Analysis</h1>
      <div className="mx-auto max-w-4xl">
        <Card className="border-zinc-800 bg-zinc-950 p-6">
          <CardContent className="p-0">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="investmentIdea"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-lg">Describe your real estate investment idea</FormLabel>
                      <FormDescription>
                        Include details like location, property type, budget, and your investment goals.
                      </FormDescription>
                      <FormControl>
                        <Textarea
                          placeholder="I'm planning to invest in a 2BHK apartment in Pune, Maharashtra with a budget of ₹80 lakhs. The area is developing with new IT parks nearby. I'm looking for capital appreciation over 5 years..."
                          className="min-h-[150px] bg-zinc-900 text-white"
                          {...field}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <Button
                  type="submit"
                  className="w-full bg-emerald-600 text-white hover:bg-emerald-700"
                  disabled={isAnalyzing}
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      Analyze Investment <ArrowRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </form>
            </Form>

            {isAnalyzing && (
              <div className="mt-8 space-y-4">
                <p className="text-center text-gray-400">Analyzing your investment idea...</p>
                <Progress value={progress} className="h-2 bg-zinc-800" indicatorClassName="bg-emerald-500" />
                <div className="grid grid-cols-3 gap-4 text-center text-sm text-gray-400">
                  <div>Collecting data</div>
                  <div>Processing factors</div>
                  <div>Generating insights</div>
                </div>
              </div>
            )}

            {result && (
              <div className="mt-8 space-y-8">
                <div className="grid gap-6 md:grid-cols-2">
                  <div className="space-y-2 rounded-lg border border-zinc-800 bg-zinc-900 p-6">
                    <h3 className="text-lg font-medium">Viability Score</h3>
                    <div className="flex items-end justify-between">
                      <div className={`text-4xl font-bold ${getScoreColor(result.viabilityScore)}`}>
                        {result.viabilityScore}%
                      </div>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div className="flex cursor-help items-center text-sm text-gray-400">
                              <InfoIcon className="mr-1 h-4 w-4" />
                              What's this?
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-xs">
                              The viability score indicates the overall potential of your investment based on multiple
                              factors including location, market trends, and economic indicators.
                            </p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    <Progress
                      value={result.viabilityScore}
                      className="h-2 bg-zinc-800"
                      indicatorClassName={getScoreProgressColor(result.viabilityScore)}
                    />
                  </div>

                  <div className="space-y-2 rounded-lg border border-zinc-800 bg-zinc-900 p-6">
                    <h3 className="text-lg font-medium">Success Rate</h3>
                    <div className="flex items-end justify-between">
                      <div className={`text-4xl font-bold ${getScoreColor(result.successRate)}`}>
                        {result.successRate}%
                      </div>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div className="flex cursor-help items-center text-sm text-gray-400">
                              <InfoIcon className="mr-1 h-4 w-4" />
                              What's this?
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-xs">
                              The success rate represents the probability of achieving your stated investment goals
                              based on historical data and market projections.
                            </p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    <Progress
                      value={result.successRate}
                      className="h-2 bg-zinc-800"
                      indicatorClassName={getScoreProgressColor(result.successRate)}
                    />
                  </div>
                </div>

                <Alert className="border-emerald-800 bg-emerald-950">
                  <ThumbsUp className="h-4 w-4 text-emerald-500" />
                  <AlertTitle className="text-emerald-500">Investment Strengths</AlertTitle>
                  <AlertDescription>
                    <ul className="mt-2 list-inside list-disc space-y-1">
                      {result.strengths.map((strength, index) => (
                        <li key={index} className="text-gray-300">
                          {strength}
                        </li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>

                <Alert className="border-amber-800 bg-amber-950">
                  <AlertCircle className="h-4 w-4 text-amber-500" />
                  <AlertTitle className="text-amber-500">Areas of Concern</AlertTitle>
                  <AlertDescription>
                    <ul className="mt-2 list-inside list-disc space-y-1">
                      {result.weaknesses.map((weakness, index) => (
                        <li key={index} className="text-gray-300">
                          {weakness}
                        </li>
                      ))}
                    </ul>
                  </AlertDescription>
                </Alert>

                <div className="rounded-lg border border-zinc-800 bg-zinc-900 p-6">
                  <h3 className="mb-4 text-lg font-medium text-emerald-500">Recommendations to Improve</h3>
                  <ul className="space-y-3">
                    {result.recommendations.map((recommendation, index) => (
                      <li key={index} className="flex items-start rounded-md bg-zinc-950 p-3">
                        <CheckCircle2 className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-emerald-500" />
                        <span>{recommendation}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function InfoIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <path d="M12 16v-4" />
      <path d="M12 8h.01" />
    </svg>
  )
}

