import { Button } from "@/components/ui/button"
import { ArrowRight, BarChart2, Building2, LineChart } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative h-[90vh] w-full overflow-hidden">
        <div className="absolute inset-0 z-0">
          <Image
            src="/placeholder.svg?height=1080&width=1920"
            alt="Modern real estate in India"
            fill
            className="object-cover brightness-[0.3]"
            priority
          />
        </div>
        <div className="relative z-10 flex h-full flex-col items-center justify-center px-4 text-center">
          <h1 className="mb-6 text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
            <span className="text-emerald-500">Data-Driven</span> Real Estate
            <br />
            Investment Decisions
          </h1>
          <p className="mb-8 max-w-2xl text-lg text-gray-300 sm:text-xl">
            ValueLab helps investors make informed real estate investment decisions in India with AI-powered viability
            scores and actionable insights.
          </p>
          <div className="flex flex-col space-y-4 sm:flex-row sm:space-x-4 sm:space-y-0">
            <Button asChild size="lg" className="bg-emerald-600 text-white hover:bg-emerald-700">
              <Link href="/analysis">
                Analyze Your Investment <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link href="/about">Learn More</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-zinc-900 py-20">
        <div className="container mx-auto px-4">
          <h2 className="mb-12 text-center text-3xl font-bold text-emerald-500 sm:text-4xl">How ValueLab Works</h2>
          <div className="grid gap-8 md:grid-cols-3">
            <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-6 transition-all hover:border-emerald-500/50">
              <div className="mb-4 rounded-full bg-emerald-500/10 p-3 text-emerald-500 w-fit">
                <Building2 className="h-6 w-6" />
              </div>
              <h3 className="mb-3 text-xl font-semibold">Input Your Idea</h3>
              <p className="text-gray-400">
                Describe your real estate investment idea in our ChatGPT-style interface. We'll analyze it using
                multiple open-source datasets.
              </p>
            </div>
            <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-6 transition-all hover:border-emerald-500/50">
              <div className="mb-4 rounded-full bg-emerald-500/10 p-3 text-emerald-500 w-fit">
                <BarChart2 className="h-6 w-6" />
              </div>
              <h3 className="mb-3 text-xl font-semibold">Get Your Score</h3>
              <p className="text-gray-400">
                Receive a comprehensive viability score based on cost, demography, government policies, and other
                critical factors.
              </p>
            </div>
            <div className="rounded-lg border border-zinc-800 bg-zinc-950 p-6 transition-all hover:border-emerald-500/50">
              <div className="mb-4 rounded-full bg-emerald-500/10 p-3 text-emerald-500 w-fit">
                <LineChart className="h-6 w-6" />
              </div>
              <h3 className="mb-3 text-xl font-semibold">Actionable Insights</h3>
              <p className="text-gray-400">
                Get real-time recommendations on how to improve your investment idea and increase its chances of
                success.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-emerald-900/20 to-emerald-600/20 py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="mb-6 text-3xl font-bold sm:text-4xl">Ready to Make Data-Driven Investment Decisions?</h2>
          <p className="mx-auto mb-8 max-w-2xl text-lg text-gray-300">
            Join investors across India who are using ValueLab to validate their real estate investment ideas before
            committing capital.
          </p>
          <Button asChild size="lg" className="bg-emerald-600 text-white hover:bg-emerald-700">
            <Link href="/analysis">Try ValueLab Now</Link>
          </Button>
        </div>
      </section>
    </div>
  )
}

