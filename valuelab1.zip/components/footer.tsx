import Link from "next/link"

export default function Footer() {
  return (
    <footer className="border-t border-zinc-800 bg-black py-12">
      <div className="container mx-auto px-4">
        <div className="grid gap-8 md:grid-cols-4">
          <div>
            <h3 className="mb-4 text-lg font-bold text-emerald-500">ValueLab</h3>
            <p className="text-sm text-gray-400">
              Data-driven real estate investment decisions for India's growing market.
            </p>
          </div>
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase text-gray-300">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/" className="text-gray-400 transition-colors hover:text-emerald-500">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-400 transition-colors hover:text-emerald-500">
                  About
                </Link>
              </li>
              <li>
                <Link href="/analysis" className="text-gray-400 transition-colors hover:text-emerald-500">
                  Investment Analysis
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-400 transition-colors hover:text-emerald-500">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase text-gray-300">Legal</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="#" className="text-gray-400 transition-colors hover:text-emerald-500">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 transition-colors hover:text-emerald-500">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 transition-colors hover:text-emerald-500">
                  Disclaimer
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase text-gray-300">Connect</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a
                  href="mailto:harshalthorat635@gmail.com"
                  className="text-gray-400 transition-colors hover:text-emerald-500"
                >
                  harshalthorat635@gmail.com
                </a>
              </li>
              <li>
                <a
                  href="mailto:vedantpawar5099@gmail.com"
                  className="text-gray-400 transition-colors hover:text-emerald-500"
                >
                  vedantpawar5099@gmail.com
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t border-zinc-800 pt-8 text-center text-sm text-gray-400">
          <p>© {new Date().getFullYear()} ValueLab. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

