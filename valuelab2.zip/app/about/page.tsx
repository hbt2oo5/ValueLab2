import { Card, CardContent } from "@/components/ui/card"
import { Database, MapPin, Target } from "lucide-react"
import Image from "next/image"

export default function AboutPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative py-20">
        <div className="container mx-auto px-4">
          <div className="grid items-center gap-12 md:grid-cols-2">
            <div>
              <h1 className="mb-6 text-4xl font-bold tracking-tight text-emerald-500 sm:text-5xl">About ValueLab</h1>
              <p className="mb-6 text-xl text-gray-300">
                ValueLab helps investors make data-driven real estate investment decisions by providing viability scores
                and actionable insights.
              </p>
              <p className="text-gray-400">
                Our platform is dedicated to India's real estate sector, covering all varieties of real estate
                investments. We combine advanced data analytics with AI to help you make informed decisions.
              </p>
            </div>
            <div className="relative h-[400px] w-full overflow-hidden rounded-xl">
              <Image src="/images/team-meeting.jpg" alt="ValueLab team" fill className="object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="bg-zinc-900 py-20">
        <div className="container mx-auto px-4">
          <h2 className="mb-12 text-center text-3xl font-bold text-emerald-500">Our Mission</h2>
          <div className="mx-auto max-w-3xl text-center">
            <p className="mb-8 text-xl text-gray-300">
              To democratize access to high-quality investment data and analysis for real estate investors in India,
              enabling them to make more informed decisions and reduce risk.
            </p>
            <div className="grid gap-8 md:grid-cols-3">
              <Card className="border-zinc-800 bg-zinc-950">
                <CardContent className="flex flex-col items-center p-6 text-center">
                  <Target className="mb-4 h-10 w-10 text-emerald-500" />
                  <h3 className="mb-2 text-lg font-semibold">Accuracy</h3>
                  <p className="text-sm text-gray-400">Providing precise and reliable investment insights</p>
                </CardContent>
              </Card>
              <Card className="border-zinc-800 bg-zinc-950">
                <CardContent className="flex flex-col items-center p-6 text-center">
                  <Database className="mb-4 h-10 w-10 text-emerald-500" />
                  <h3 className="mb-2 text-lg font-semibold">Data-Driven</h3>
                  <p className="text-sm text-gray-400">Leveraging multiple datasets for comprehensive analysis</p>
                </CardContent>
              </Card>
              <Card className="border-zinc-800 bg-zinc-950">
                <CardContent className="flex flex-col items-center p-6 text-center">
                  <MapPin className="mb-4 h-10 w-10 text-emerald-500" />
                  <h3 className="mb-2 text-lg font-semibold">India-Focused</h3>
                  <p className="text-sm text-gray-400">Specialized for the unique Indian real estate market</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="mb-12 text-center text-3xl font-bold text-emerald-500">Our Team</h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <div className="group overflow-hidden rounded-lg border border-zinc-800 bg-zinc-950 p-6 text-center">
              <div className="mx-auto mb-4 h-32 w-32 overflow-hidden rounded-full">
                <Image
                  src="/images/team-member-1.jpg"
                  alt="Team Member"
                  width={128}
                  height={128}
                  className="h-full w-full object-cover"
                />
              </div>
              <h3 className="mb-1 text-xl font-semibold">Harshal Thorat</h3>
              <p className="mb-4 text-sm text-emerald-500">Founder & CEO</p>
              <p className="text-sm text-gray-400">
                Real estate expert with over 10 years of experience in the Indian market.
              </p>
            </div>

            <div className="group overflow-hidden rounded-lg border border-zinc-800 bg-zinc-950 p-6 text-center">
              <div className="mx-auto mb-4 h-32 w-32 overflow-hidden rounded-full">
                <Image
                  src="/images/team-member-2.jpg"
                  alt="Team Member"
                  width={128}
                  height={128}
                  className="h-full w-full object-cover"
                />
              </div>
              <h3 className="mb-1 text-xl font-semibold">Vedant Pawar</h3>
              <p className="mb-4 text-sm text-emerald-500">CTO</p>
              <p className="text-sm text-gray-400">
                Data scientist specializing in predictive analytics for real estate investments.
              </p>
            </div>

            <div className="group overflow-hidden rounded-lg border border-zinc-800 bg-zinc-950 p-6 text-center">
              <div className="mx-auto mb-4 h-32 w-32 overflow-hidden rounded-full">
                <Image
                  src="/images/team-member-3.jpg"
                  alt="Team Member"
                  width={128}
                  height={128}
                  className="h-full w-full object-cover"
                />
              </div>
              <h3 className="mb-1 text-xl font-semibold">Priya Sharma</h3>
              <p className="mb-4 text-sm text-emerald-500">Head of Research</p>
              <p className="text-sm text-gray-400">
                Expert in market research and analysis of real estate trends across India.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-zinc-900 py-20">
        <div className="container mx-auto px-4">
          <h2 className="mb-12 text-center text-3xl font-bold text-emerald-500">How ValueLab Works</h2>
          <div className="mx-auto max-w-4xl">
            <div className="relative">
              <div className="absolute left-[15px] top-0 h-full w-[2px] bg-zinc-800 md:left-1/2 md:-ml-[1px]"></div>
              <div className="space-y-12">
                {/* Step 1 */}
                <div className="relative md:flex md:items-center">
                  <div className="mb-6 md:mb-0 md:w-1/2 md:pr-8 md:text-right">
                    <h3 className="text-xl font-semibold text-emerald-400">Data Collection</h3>
                    <p className="mt-2 text-gray-400">
                      We aggregate data from multiple open-source datasets, including Kaggle, government records, and
                      market reports.
                    </p>
                  </div>
                  <div className="absolute left-0 flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500 text-black md:left-1/2 md:-ml-4">
                    <span className="text-sm font-bold">1</span>
                  </div>
                  <div className="md:w-1/2 md:pl-8"></div>
                </div>

                {/* Step 2 */}
                <div className="relative md:flex md:items-center">
                  <div className="md:w-1/2 md:pr-8"></div>
                  <div className="absolute left-0 flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500 text-black md:left-1/2 md:-ml-4">
                    <span className="text-sm font-bold">2</span>
                  </div>
                  <div className="mb-6 md:mb-0 md:w-1/2 md:pl-8">
                    <h3 className="text-xl font-semibold text-emerald-400">Data Cleaning</h3>
                    <p className="mt-2 text-gray-400">
                      Before processing, all datasets are cleaned and normalized to ensure accuracy and consistency.
                    </p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="relative md:flex md:items-center">
                  <div className="mb-6 md:mb-0 md:w-1/2 md:pr-8 md:text-right">
                    <h3 className="text-xl font-semibold text-emerald-400">Analysis</h3>
                    <p className="mt-2 text-gray-400">
                      Our algorithms analyze your investment idea based on factors like cost, demography, and government
                      policies.
                    </p>
                  </div>
                  <div className="absolute left-0 flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500 text-black md:left-1/2 md:-ml-4">
                    <span className="text-sm font-bold">3</span>
                  </div>
                  <div className="md:w-1/2 md:pl-8"></div>
                </div>

                {/* Step 4 */}
                <div className="relative md:flex md:items-center">
                  <div className="md:w-1/2 md:pr-8"></div>
                  <div className="absolute left-0 flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500 text-black md:left-1/2 md:-ml-4">
                    <span className="text-sm font-bold">4</span>
                  </div>
                  <div className="mb-6 md:mb-0 md:w-1/2 md:pl-8">
                    <h3 className="text-xl font-semibold text-emerald-400">Results Generation</h3>
                    <p className="mt-2 text-gray-400">
                      We generate a viability score, success rate, and actionable recommendations to improve your
                      investment.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid gap-8 md:grid-cols-4">
            <div className="text-center">
              <p className="text-4xl font-bold text-emerald-500">500+</p>
              <p className="mt-2 text-gray-400">Investment Ideas Analyzed</p>
            </div>
            <div className="text-center">
              <p className="text-4xl font-bold text-emerald-500">28</p>
              <p className="mt-2 text-gray-400">Indian States Covered</p>
            </div>
            <div className="text-center">
              <p className="text-4xl font-bold text-emerald-500">15+</p>
              <p className="mt-2 text-gray-400">Data Sources</p>
            </div>
            <div className="text-center">
              <p className="text-4xl font-bold text-emerald-500">92%</p>
              <p className="mt-2 text-gray-400">Accuracy Rate</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

