import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Brain, Building2, TreePine, BarChart as ChartBar, Users, Mail, ArrowRight } from 'lucide-react';
import { evaluateIdea } from './utils/evaluationLogic';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-white">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/evaluate" element={<EvaluationPage />} />
          <Route path="/investors" element={<InvestorsPage />} />
          <Route path="/analytics" element={<AnalyticsPage />} />
        </Routes>
      </div>
    </Router>
  );
}

function HomePage() {
  return (
    <>
      <header className="bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <Brain className="w-8 h-8" />
            <span className="text-xl font-bold">ValueVistaLab</span>
          </Link>
          <div className="hidden md:flex space-x-8">
            <Link to="/evaluate" className="hover:text-blue-200">Evaluate</Link>
            <Link to="/investors" className="hover:text-blue-200">Investors</Link>
            <Link to="/analytics" className="hover:text-blue-200">Analytics</Link>
            <a href="#contact" className="hover:text-blue-200">Contact</a>
          </div>
        </nav>
        
        <div className="container mx-auto px-6 py-20 text-center">
          <h1 className="text-5xl font-bold mb-6">AI-Powered Idea Evaluation Platform</h1>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Transform your innovative ideas into viable opportunities with our data-driven analysis platform.
          </p>
          <Link 
            to="/evaluate" 
            className="inline-flex items-center bg-white text-blue-600 px-8 py-3 rounded-full font-semibold hover:bg-blue-50 transition"
          >
            Evaluate Your Idea
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </header>

      <section id="features" className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-16">Powerful Features</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Link to="/evaluate">
              <FeatureCard
                icon={<ChartBar className="w-8 h-8 text-blue-600" />}
                title="ML Model Evaluation"
                description="Get comprehensive scoring based on market demand, feasibility, and team expertise"
              />
            </Link>
            <Link to="/investors">
              <FeatureCard
                icon={<Users className="w-8 h-8 text-blue-600" />}
                title="Investor Matching"
                description="Connect with potential investors who align with your sector and vision"
              />
            </Link>
            <Link to="/analytics">
              <FeatureCard
                icon={<Brain className="w-8 h-8 text-blue-600" />}
                title="Smart Analytics"
                description="Receive detailed insights and recommendations for your business idea"
              />
            </Link>
          </div>
        </div>
      </section>

      <section id="sectors" className="py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-16">Supported Sectors</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Link to="/evaluate?sector=startup">
              <SectorCard
                icon={<Building2 className="w-12 h-12 text-blue-600" />}
                title="Business Startups"
                image="https://images.unsplash.com/photo-1553729459-efe14ef6055d?auto=format&fit=crop&w=800"
              />
            </Link>
            <Link to="/evaluate?sector=agriculture">
              <SectorCard
                icon={<TreePine className="w-12 h-12 text-green-600" />}
                title="Agriculture"
                image="https://images.unsplash.com/photo-1625246333195-78d9c38ad449?auto=format&fit=crop&w=800"
              />
            </Link>
            <Link to="/evaluate?sector=realestate">
              <SectorCard
                icon={<Building2 className="w-12 h-12 text-purple-600" />}
                title="Real Estate"
                image="https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=800"
              />
            </Link>
          </div>
        </div>
      </section>

      <section id="contact" className="py-20 bg-gray-50">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold mb-8">Get In Touch</h2>
          <div className="flex items-center justify-center space-x-2 text-xl">
            <Mail className="w-6 h-6" />
            <a href="mailto:vedantpawar5099@gmail.com" className="text-blue-600 hover:text-blue-800">
              vedantpawar5099@gmail.com
            </a>
          </div>
        </div>
      </section>
    </>
  );
}

function EvaluationPage() {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    sector: 'startup'
  });
  const [evaluationResult, setEvaluationResult] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    const result = evaluateIdea(
      formData.sector,
      formData.description,
      formData.title
    );
    setEvaluationResult(result);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-6">
        <h1 className="text-4xl font-bold mb-8">Idea Evaluation</h1>
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-white rounded-xl shadow-sm p-8">
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Project Title
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter your project title"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Project Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  rows={4}
                  placeholder="Describe your project idea"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Sector
                </label>
                <select
                  value={formData.sector}
                  onChange={(e) => setFormData({ ...formData, sector: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="startup">Business Startup</option>
                  <option value="agriculture">Agriculture</option>
                  <option value="realestate">Real Estate</option>
                </select>
              </div>
              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition"
              >
                Evaluate Now
              </button>
            </form>
          </div>

          {evaluationResult && (
            <div className="bg-white rounded-xl shadow-sm p-8">
              <h2 className="text-2xl font-bold mb-6">Evaluation Results</h2>
              
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-700">Viability Score</span>
                  <span className="text-2xl font-bold text-blue-600">{evaluationResult.score}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div
                    className="bg-blue-600 h-2.5 rounded-full"
                    style={{ width: `${evaluationResult.score}%` }}
                  ></div>
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Market Insights</h3>
                  <div className="space-y-2 text-gray-600">
                    <p>{evaluationResult.marketInsights.growth}</p>
                    <p>{evaluationResult.marketInsights.competition}</p>
                    <p>{evaluationResult.marketInsights.potential}</p>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-2">Feedback</h3>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    {evaluationResult.feedback.map((item, index) => (
                      <li key={index}>{item}</li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-2">Recommendations</h3>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    {evaluationResult.recommendations.map((item, index) => (
                      <li key={index}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function InvestorsPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-6">
        <h1 className="text-4xl font-bold mb-8">Investor Matching</h1>
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-white rounded-xl shadow-sm p-8">
            <h2 className="text-2xl font-semibold mb-4">Find Investors</h2>
            <p className="text-gray-600 mb-6">
              Connect with investors who match your sector and investment requirements.
            </p>
            <button className="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700 transition">
              Start Matching
            </button>
          </div>
          <div className="bg-white rounded-xl shadow-sm p-8">
            <h2 className="text-2xl font-semibold mb-4">Investor Dashboard</h2>
            <p className="text-gray-600 mb-6">
              Track your investor connections and communication in one place.
            </p>
            <button className="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700 transition">
              View Dashboard
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function AnalyticsPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-6">
        <h1 className="text-4xl font-bold mb-8">Smart Analytics</h1>
        <div className="bg-white rounded-xl shadow-sm p-8">
          <h2 className="text-2xl font-semibold mb-6">Project Insights</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="p-6 bg-gray-50 rounded-lg">
              <h3 className="text-lg font-semibold mb-2">Market Analysis</h3>
              <p className="text-gray-600">Detailed market trend analysis and competitor insights.</p>
            </div>
            <div className="p-6 bg-gray-50 rounded-lg">
              <h3 className="text-lg font-semibold mb-2">Financial Projections</h3>
              <p className="text-gray-600">Revenue forecasts and financial viability assessment.</p>
            </div>
            <div className="p-6 bg-gray-50 rounded-lg">
              <h3 className="text-lg font-semibold mb-2">Risk Assessment</h3>
              <p className="text-gray-600">Comprehensive risk analysis and mitigation strategies.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function FeatureCard({ icon, title, description }) {
  return (
    <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition">
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

function SectorCard({ icon, title, image }) {
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition">
      <div className="h-48 relative">
        <img src={image} alt={title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
          <div className="text-white text-center">
            {icon}
            <h3 className="text-xl font-semibold mt-2">{title}</h3>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;