import { marketData } from '../data/marketData';

interface EvaluationResult {
  score: number;
  feedback: string[];
  marketInsights: {
    growth: string;
    competition: string;
    potential: string;
  };
  recommendations: string[];
}

export function evaluateIdea(
  sector: 'startup' | 'agriculture' | 'realestate',
  description: string,
  title: string
): EvaluationResult {
  const sectorData = marketData[sector];
  
  // Simulate ML evaluation with weighted scoring
  const score = calculateScore(sector, description, title);
  
  // Generate feedback based on sector and description
  const feedback = generateFeedback(sector, score, sectorData);
  
  // Market insights based on sector data
  const marketInsights = {
    growth: `${sectorData.metrics.growthRate} annual growth rate in the ${sector} sector`,
    competition: determineCompetition(sector, sectorData),
    potential: `₹${calculateMarketPotential(sectorData)} Cr estimated market potential`
  };
  
  // Generate recommendations
  const recommendations = generateRecommendations(sector, score, sectorData);
  
  return {
    score,
    feedback,
    marketInsights,
    recommendations
  };
}

function calculateScore(sector: string, description: string, title: string): number {
  // Keywords that might indicate unrealistic or poorly planned ideas
  const redFlags = [
    'quantum', 'time travel', 'space', 'underwater', 'flying',
    'teleport', 'perpetual motion', 'unlimited', 'miracle',
    'revolutionary', 'groundbreaking', 'no competition'
  ];
  
  // Check for red flags in title and description
  const combinedText = (title + ' ' + description).toLowerCase();
  const flagsFound = redFlags.filter(flag => combinedText.includes(flag)).length;
  
  // Base score calculation
  let baseScore = Math.random() * 20 + 40; // Base score between 40-60 for questionable ideas
  
  // Penalty for each red flag found
  baseScore = Math.max(30, baseScore - (flagsFound * 5));
  
  // Sector-specific adjustments
  const sectorBonus = {
    startup: 2,
    agriculture: 3,
    realestate: 2
  }[sector] || 0;
  
  // Additional penalties for very short descriptions (lack of detail)
  if (description.length < 100) {
    baseScore -= 10;
  }
  
  return Math.min(100, Math.round(Math.max(30, baseScore + sectorBonus)));
}

function generateFeedback(sector: string, score: number, sectorData: any): string[] {
  const feedback = [];
  
  if (score < 50) {
    feedback.push(`Significant concerns about feasibility and market viability`);
    feedback.push(`The idea requires substantial refinement and practical considerations`);
  } else if (score < 70) {
    feedback.push(`The idea needs refinement to compete in the current market`);
    feedback.push(`Focus on unique value proposition and market differentiation`);
  } else if (score >= 70) {
    feedback.push(`Good opportunity with some areas for improvement`);
    feedback.push(`Consider the competitive landscape in ${sector} sector`);
  }
  
  feedback.push(`Average success rate in this sector: ${sectorData.metrics.successRate}`);
  return feedback;
}

function determineCompetition(sector: string, sectorData: any): string {
  const competitionLevels = sectorData.sectors.map(s => s.competition);
  const highCount = competitionLevels.filter(c => c === 'high').length;
  
  if (highCount >= 3) return 'Highly competitive market';
  if (highCount >= 1) return 'Moderately competitive market';
  return 'Relatively less competitive market';
}

function calculateMarketPotential(sectorData: any): number {
  const totalMarketSize = sectorData.sectors.reduce((acc, curr) => acc + curr.marketSize, 0);
  return Math.round(totalMarketSize * 1.5); // Estimated potential including growth
}

function generateRecommendations(sector: string, score: number, sectorData: any): string[] {
  const recommendations = [];
  
  // Add sector-specific recommendations
  if (sector === 'startup') {
    recommendations.push(`Focus on technology integration and scalability`);
    recommendations.push(`Consider the ${sectorData.metrics.avgFunding} average funding requirement`);
  } else if (sector === 'agriculture') {
    recommendations.push(`Emphasize sustainable practices and technology adoption`);
    recommendations.push(`Target rural employment generation potential`);
  } else if (sector === 'realestate') {
    recommendations.push(`Consider market location and demographic trends`);
    recommendations.push(`Evaluate regulatory compliance requirements`);
  }
  
  // Add score-based recommendations
  if (score < 50) {
    recommendations.push(`Conduct thorough feasibility study and market research`);
    recommendations.push(`Develop a more practical and achievable business plan`);
  } else if (score < 75) {
    recommendations.push(`Strengthen your unique value proposition`);
    recommendations.push(`Conduct detailed market research and validation`);
  }
  
  return recommendations;
}