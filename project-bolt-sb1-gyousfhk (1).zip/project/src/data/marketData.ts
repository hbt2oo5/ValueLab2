// Sample market data for Indian sectors
export const marketData = {
  startup: {
    sectors: [
      { name: "Technology", growth: 28.5, marketSize: 250, competition: "medium" },
      { name: "E-commerce", growth: 32.1, marketSize: 180, competition: "high" },
      { name: "EdTech", growth: 25.8, marketSize: 120, competition: "medium" },
      { name: "FinTech", growth: 35.2, marketSize: 200, competition: "high" },
      { name: "HealthTech", growth: 22.4, marketSize: 150, competition: "low" }
    ],
    metrics: {
      avgFunding: "₹2.5 Cr",
      successRate: "32%",
      growthRate: "27%",
      employmentGeneration: "High"
    }
  },
  agriculture: {
    sectors: [
      { name: "Organic Farming", growth: 18.2, marketSize: 85, competition: "low" },
      { name: "AgriTech", growth: 24.5, marketSize: 95, competition: "medium" },
      { name: "Food Processing", growth: 15.8, marketSize: 180, competition: "high" },
      { name: "Smart Irrigation", growth: 20.4, marketSize: 75, competition: "low" },
      { name: "Sustainable Farming", growth: 22.1, marketSize: 90, competition: "medium" }
    ],
    metrics: {
      avgFunding: "₹1.8 Cr",
      successRate: "45%",
      growthRate: "20%",
      employmentGeneration: "Very High"
    }
  },
  realestate: {
    sectors: [
      { name: "Residential", growth: 15.5, marketSize: 350, competition: "high" },
      { name: "Commercial", growth: 18.2, marketSize: 280, competition: "medium" },
      { name: "PropTech", growth: 28.4, marketSize: 120, competition: "low" },
      { name: "Co-living", growth: 25.6, marketSize: 90, competition: "medium" },
      { name: "Warehousing", growth: 22.8, marketSize: 150, competition: "low" }
    ],
    metrics: {
      avgFunding: "₹5.2 Cr",
      successRate: "38%",
      growthRate: "22%",
      employmentGeneration: "High"
    }
  }
};